﻿from __future__ import annotations

import argparse
import json
import os
import traceback
import uuid
from datetime import datetime
from urllib.parse import parse_qs, unquote, urlparse

try:
    from airflow.decorators import task as airflow_task
except ImportError:
    airflow_task = None

try:
    from airflow.providers.postgres.hooks.postgres import (
        PostgresHook as AirflowPostgresHook,
    )
except ImportError:
    AirflowPostgresHook = None

try:
    from airflow.providers.amazon.aws.hooks.redshift_sql import (
        RedshiftSQLHook as AirflowRedshiftSQLHook,
    )
except ImportError:
    AirflowRedshiftSQLHook = None

try:
    from airflow.providers.vertica.hooks.vertica import (
        VerticaHook as AirflowVerticaHook,
    )
except ImportError:
    AirflowVerticaHook = None

try:
    import psycopg2
except ImportError:
    psycopg2 = None

try:
    import redshift_connector
except ImportError:
    redshift_connector = None

try:
    import vertica_python
except ImportError:
    vertica_python = None


# ****** standalone 방식으로 수행시 meta는 redshift 사용, airflow 방식으로 수행시 meta는 postgres 사용 *******
# ****** meta 테이블의 config_option 컬럼 "SOURCE_CONN_NAME":"vertica_conn" 이면 export AIRFLOW_CONN_VERTICA_CONN="vertica://user:password@host:5433/database" 필요 *****
# ****** meta 테이블의 config_option 컬럼 "TARGET_CONN_NAME":"redshift_conn" 이면 export AIRFLOW_CONN_REDSHIFT_CONN="redshift://user:password@host:5439/database" 필요 *****
# ****** standalone 방식 수행시 메타 db 접속정보로 export AIRFLOW_CONN_REDSHIFT_CONN="redshift://user:password@host:5439/database" 필요 ******
# ****** airflow meta 정보는 webconsole 에서 provider "postgres_conn" 으로 커넥션 생성 ******
META_POSTGRES_CONN_ID = "postgres_conn"
DEFAULT_META_POSTGRES_CONN_ID = META_POSTGRES_CONN_ID
HIST_TABLE_NAME = "etl_job_run_dtl_hist"
CHUNK_SIZE = 5000
USE_AIRFLOW_HOOKS = True


# ****** standalone 전용 ******
def build_airflow_conn_env_name(conn_id: str) -> str:
    normalized = "".join(ch if ch.isalnum() else "_" for ch in conn_id.upper())
    return f"AIRFLOW_CONN_{normalized}"


# ****** standalone 전용 ******
def get_env_value(conn_id: str, suffix: str, default: str = "") -> str:
    prefix = "".join(ch if ch.isalnum() else "_" for ch in conn_id.upper())
    return os.getenv(f"{prefix}_{suffix}", default)


# ****** standalone 전용 ******
def parse_postgres_conn_uri(conn_id: str, uri: str) -> dict:
    parsed = urlparse(uri)
    if parsed.scheme not in ("postgres", "postgresql"):
        raise ValueError(
            f"{conn_id}: unsupported connection URI scheme "
            f"[{parsed.scheme}]. Use postgres:// or postgresql://."
        )

    query = parse_qs(parsed.query)
    conn_kwargs = {
        "host": parsed.hostname,
        "port": parsed.port or 5432,
        "dbname": unquote(parsed.path.lstrip("/")),
        "user": unquote(parsed.username or ""),
        "password": unquote(parsed.password or ""),
    }

    for key, values in query.items():
        if values:
            conn_kwargs[key] = values[-1]

    return {k: v for k, v in conn_kwargs.items() if v not in (None, "")}


# ****** standalone 전용 ******
def build_postgres_conn_kwargs_from_env(conn_id: str) -> dict:
    airflow_conn_uri = os.getenv(build_airflow_conn_env_name(conn_id))
    if airflow_conn_uri:
        return parse_postgres_conn_uri(conn_id, airflow_conn_uri)

    kwargs = {
        "host": get_env_value(conn_id, "HOST"),
        "port": get_env_value(conn_id, "PORT", "5432"),
        "dbname": get_env_value(conn_id, "DBNAME") or get_env_value(conn_id, "DATABASE"),
        "user": get_env_value(conn_id, "USER"),
        "password": get_env_value(conn_id, "PASSWORD"),
    }

    extra_raw = get_env_value(conn_id, "EXTRA")
    if extra_raw:
        extra = json.loads(extra_raw)
        if not isinstance(extra, dict):
            raise ValueError(f"{conn_id}_EXTRA must be JSON object")
        kwargs.update(extra)

    missing = [key for key in ("host", "dbname", "user") if not kwargs.get(key)]
    if missing:
        env_name = build_airflow_conn_env_name(conn_id)
        raise ValueError(
            f"Postgres connection [{conn_id}] is not configured. "
            f"Set {env_name}=postgresql://user:password@host:5432/dbname "
            f"or set {conn_id.upper()}_HOST, _DBNAME, _USER, _PASSWORD. "
            f"Missing: {missing}"
        )

    return {k: v for k, v in kwargs.items() if v not in (None, "")}


# ****** standalone 전용 ******
def parse_redshift_conn_uri(conn_id: str, uri: str) -> dict:
    parsed = urlparse(uri)
    if parsed.scheme not in ("redshift", "redshift+redshift_connector"):
        raise ValueError(
            f"{conn_id}: unsupported connection URI scheme "
            f"[{parsed.scheme}]. Use redshift://."
        )

    query = parse_qs(parsed.query)
    conn_kwargs = {
        "host": parsed.hostname,
        "port": parsed.port or 5439,
        "database": unquote(parsed.path.lstrip("/")),
        "user": unquote(parsed.username or ""),
        "password": unquote(parsed.password or ""),
    }

    for key, values in query.items():
        if values:
            conn_kwargs[key] = values[-1]

    return {k: v for k, v in conn_kwargs.items() if v not in (None, "")}


# ****** standalone 전용 ******
def build_redshift_conn_kwargs_from_env(conn_id: str) -> dict:
    airflow_conn_uri = os.getenv(build_airflow_conn_env_name(conn_id))
    if airflow_conn_uri:
        return parse_redshift_conn_uri(conn_id, airflow_conn_uri)

    kwargs = {
        "host": get_env_value(conn_id, "HOST"),
        "port": int(get_env_value(conn_id, "PORT", "5439")),
        "database": get_env_value(conn_id, "DATABASE") or get_env_value(conn_id, "DBNAME"),
        "user": get_env_value(conn_id, "USER"),
        "password": get_env_value(conn_id, "PASSWORD"),
    }

    extra_raw = get_env_value(conn_id, "EXTRA")
    if extra_raw:
        extra = json.loads(extra_raw)
        if not isinstance(extra, dict):
            raise ValueError(f"{conn_id}_EXTRA must be JSON object")
        kwargs.update(extra)

    missing = [key for key in ("host", "database", "user") if not kwargs.get(key)]
    if missing:
        env_name = build_airflow_conn_env_name(conn_id)
        raise ValueError(
            f"Redshift connection [{conn_id}] is not configured. "
            f"Set {env_name}=redshift://user:password@host:5439/database "
            f"or set {conn_id.upper()}_HOST, _DATABASE, _USER, _PASSWORD. "
            f"Missing: {missing}"
        )

    return {k: v for k, v in kwargs.items() if v not in (None, "")}


# ****** standalone 전용 ******
def parse_vertica_conn_uri(conn_id: str, uri: str) -> dict:
    parsed = urlparse(uri)
    if parsed.scheme not in ("vertica", "vertica-python"):
        raise ValueError(
            f"{conn_id}: unsupported connection URI scheme "
            f"[{parsed.scheme}]. Use vertica://."
        )

    query = parse_qs(parsed.query)
    conn_kwargs = {
        "host": parsed.hostname,
        "port": parsed.port or 5433,
        "database": unquote(parsed.path.lstrip("/")),
        "user": unquote(parsed.username or ""),
        "password": unquote(parsed.password or ""),
    }

    for key, values in query.items():
        if values:
            conn_kwargs[key] = values[-1]

    return {k: v for k, v in conn_kwargs.items() if v not in (None, "")}


# ****** standalone 전용 ******
def build_vertica_conn_kwargs_from_env(conn_id: str) -> dict:
    airflow_conn_uri = os.getenv(build_airflow_conn_env_name(conn_id))
    if airflow_conn_uri:
        return parse_vertica_conn_uri(conn_id, airflow_conn_uri)

    kwargs = {
        "host": get_env_value(conn_id, "HOST"),
        "port": int(get_env_value(conn_id, "PORT", "5433")),
        "database": get_env_value(conn_id, "DATABASE") or get_env_value(conn_id, "DBNAME"),
        "user": get_env_value(conn_id, "USER"),
        "password": get_env_value(conn_id, "PASSWORD"),
    }

    extra_raw = get_env_value(conn_id, "EXTRA")
    if extra_raw:
        extra = json.loads(extra_raw)
        if not isinstance(extra, dict):
            raise ValueError(f"{conn_id}_EXTRA must be JSON object")
        kwargs.update(extra)

    missing = [key for key in ("host", "database", "user") if not kwargs.get(key)]
    if missing:
        env_name = build_airflow_conn_env_name(conn_id)
        raise ValueError(
            f"Vertica connection [{conn_id}] is not configured. "
            f"Set {env_name}=vertica://user:password@host:5433/database "
            f"or set {conn_id.upper()}_HOST, _DATABASE, _USER, _PASSWORD. "
            f"Missing: {missing}"
        )

    return {k: v for k, v in kwargs.items() if v not in (None, "")}


# ****** standalone 전용 ******
class StandalonePostgresHook:
    def __init__(self, postgres_conn_id: str):
        self.postgres_conn_id = postgres_conn_id

    def get_conn(self):
        if psycopg2 is None:
            raise ImportError(
                "psycopg2 is required for standalone Python execution. "
                "Install it with: pip install psycopg2-binary"
            )
        return psycopg2.connect(**build_postgres_conn_kwargs_from_env(self.postgres_conn_id))

    def run(self, sql: str, parameters=None) -> None:
        conn = None
        cursor = None
        try:
            conn = self.get_conn()
            if hasattr(conn, "autocommit"):
                conn.autocommit = False
            cursor = conn.cursor()
            cursor.execute(sql, parameters)
            conn.commit()
        except Exception:
            if conn is not None:
                conn.rollback()
            raise
        finally:
            if cursor is not None:
                cursor.close()
            if conn is not None:
                conn.close()


# ****** standalone 전용 ******
class StandaloneRedshiftHook:
    def __init__(self, redshift_conn_id: str):
        self.redshift_conn_id = redshift_conn_id

    def get_conn(self):
        if redshift_connector is None:
            raise ImportError(
                "redshift_connector is required for standalone Python execution. "
                "Install it with: pip install redshift-connector"
            )
        return redshift_connector.connect(**build_redshift_conn_kwargs_from_env(self.redshift_conn_id))

    def run(self, sql: str, parameters=None) -> None:
        conn = None
        cursor = None
        try:
            conn = self.get_conn()
            cursor = conn.cursor()
            cursor.execute(sql, parameters)
            conn.commit()
        except Exception:
            if conn is not None:
                conn.rollback()
            raise
        finally:
            if cursor is not None:
                cursor.close()
            if conn is not None:
                conn.close()

    def get_first(self, sql: str, parameters=None):
        conn = None
        cursor = None
        try:
            conn = self.get_conn()
            cursor = conn.cursor()
            cursor.execute(sql, parameters)
            return cursor.fetchone()
        finally:
            if cursor is not None:
                cursor.close()
            if conn is not None:
                conn.close()

    def insert_rows(
        self,
        table: str,
        rows: list[tuple],
        target_fields: list[str] | None = None,
        commit_every: int = 1000,
        executemany: bool = False,
    ) -> None:
        if not rows:
            return

        fields_sql = ""
        if target_fields:
            fields_sql = " (" + ", ".join(target_fields) + ")"

        placeholders = ", ".join(["%s"] * len(rows[0]))
        insert_sql = f"INSERT INTO {table}{fields_sql} VALUES ({placeholders})"

        conn = None
        cursor = None
        try:
            conn = self.get_conn()
            cursor = conn.cursor()
            if executemany:
                cursor.executemany(insert_sql, rows)
            else:
                for row in rows:
                    cursor.execute(insert_sql, row)
            conn.commit()
        except Exception:
            if conn is not None:
                conn.rollback()
            raise
        finally:
            if cursor is not None:
                cursor.close()
            if conn is not None:
                conn.close()


# ****** standalone 전용 ******
class StandaloneVerticaHook:
    def __init__(self, vertica_conn_id: str):
        self.vertica_conn_id = vertica_conn_id

    def get_conn(self):
        if vertica_python is None:
            raise ImportError(
                "vertica_python is required for standalone Python execution. "
                "Install it with: pip install vertica-python"
            )
        return vertica_python.connect(**build_vertica_conn_kwargs_from_env(self.vertica_conn_id))


# ****** standalone + airflow 전용 ******
def get_postgres_hook(postgres_conn_id: str):
    if USE_AIRFLOW_HOOKS and AirflowPostgresHook is not None:
        return AirflowPostgresHook(postgres_conn_id=postgres_conn_id)
    return StandalonePostgresHook(postgres_conn_id=postgres_conn_id)


# ****** standalone + airflow 전용 ******
def get_redshift_hook(redshift_conn_id: str):
    if USE_AIRFLOW_HOOKS and AirflowRedshiftSQLHook is not None:
        return AirflowRedshiftSQLHook(redshift_conn_id=redshift_conn_id)
    return StandaloneRedshiftHook(redshift_conn_id=redshift_conn_id)


# ****** standalone + airflow 전용 ******
def get_vertica_hook(vertica_conn_id: str):
    if USE_AIRFLOW_HOOKS and AirflowVerticaHook is not None:
        return AirflowVerticaHook(vertica_conn_id=vertica_conn_id)
    return StandaloneVerticaHook(vertica_conn_id=vertica_conn_id)


# ****** standalone + airflow 전용 ******
def get_meta_db_hook(meta_conn_id: str):
    if USE_AIRFLOW_HOOKS:
        return get_postgres_hook(meta_conn_id)
    return get_redshift_hook(meta_conn_id)


# ****** standalone + airflow 전용 ******
def safe_json_dumps(value) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, default=str)


# ****** standalone + airflow 전용 ******
def cut_text(value: str | None, max_length: int = 4000) -> str:
    if value is None:
        return ""
    text = str(value)
    if len(text) <= max_length:
        return text
    return text[:max_length]


# ****** standalone + airflow 전용 ******
def get_task_runtime_info(**context) -> dict:
    ti = context.get("ti")
    task_obj = context.get("task")
    task_id = context.get("task_id") or getattr(task_obj, "task_id", "standalone_task")
    run_id = context.get("run_id") or f"manual__{datetime.now():%Y%m%dT%H%M%S}__{uuid.uuid4().hex[:8]}"

    return {
        "run_id": run_id,
        "task_id": task_id,
        "map_index": context.get("map_index", getattr(ti, "map_index", -1)),
    }


# ****** standalone + airflow 전용 ******
def insert_etl_run_hist(
    dag_id: str,
    run_id: str | None,
    task_id: str | None,
    map_index: int | None,
    source_table: str | None,
    target_table: str | None,
    load_option: str | None = None,
    source_conn_name: str | None = None,
    target_conn_name: str | None = None,
    input_param=None,
    config_option=None,
    create_user_id: str = "python",
    meta_conn_id: str = DEFAULT_META_POSTGRES_CONN_ID,
) -> int:
    hook = get_meta_db_hook(meta_conn_id)
    insert_sql = f"""
        INSERT INTO {HIST_TABLE_NAME} (
            dag_id, run_id, task_id, map_index, source_table, target_table,
            load_option, source_conn_name, target_conn_name,
            extract_row_count, stg_load_row_count, target_insert_count,
            target_update_count, target_delete_count,
            target_total_affected_count, file_write_row_count,
            target_file_path, status, error_message, start_tm, end_tm,
            input_param, config_option, create_user_id, create_tm, update_tm
        )
        VALUES (
            %s, %s, %s, %s, %s, %s, %s, %s, %s,
            0, 0, 0, 0, 0, 0, 0, '',
            'RUNNING', '', CURRENT_TIMESTAMP, NULL,
            %s, %s, %s, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
        )
        RETURNING run_hist_id
    """

    if not USE_AIRFLOW_HOOKS:
        insert_sql = insert_sql.replace("        RETURNING run_hist_id", "")

    conn = None
    cursor = None
    try:
        conn = hook.get_conn()
        if hasattr(conn, "autocommit"):
            conn.autocommit = False
        cursor = conn.cursor()
        cursor.execute(
            insert_sql,
            (
                dag_id, run_id, task_id, map_index, source_table or "",
                target_table or "", load_option or "", source_conn_name or "",
                target_conn_name or "", safe_json_dumps(input_param),
                safe_json_dumps(config_option), create_user_id,
            ),
        )
        if USE_AIRFLOW_HOOKS:
            run_hist_id = cursor.fetchone()[0]
        else:
            cursor.execute(
                f"""
                SELECT run_hist_id
                FROM {HIST_TABLE_NAME}
                WHERE run_id = %s
                  AND task_id = %s
                  AND map_index = %s
                ORDER BY create_tm DESC
                LIMIT 1
                """,
                (run_id, task_id, map_index),
            )
            row = cursor.fetchone()
            if row is None:
                raise ValueError(
                    f"ETL run history id not found. "
                    f"run_id={run_id}, task_id={task_id}, map_index={map_index}"
                )
            run_hist_id = row[0]
        conn.commit()
        return run_hist_id
    except Exception:
        if conn is not None:
            conn.rollback()
        raise
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()


# ****** standalone + airflow 전용 ******
def update_etl_run_hist_success(
    run_hist_id: int,
    extract_row_count: int = 0,
    stg_load_row_count: int = 0,
    target_insert_count: int = 0,
    target_update_count: int = 0,
    target_delete_count: int = 0,
    file_write_row_count: int = 0,
    target_file_path: str | None = None,
    meta_conn_id: str = DEFAULT_META_POSTGRES_CONN_ID,
) -> None:
    hook = get_meta_db_hook(meta_conn_id)
    total_affected = int(target_insert_count) + int(target_update_count) + int(target_delete_count)
    update_sql = f"""
        UPDATE {HIST_TABLE_NAME}
           SET extract_row_count = %s,
               stg_load_row_count = %s,
               target_insert_count = %s,
               target_update_count = %s,
               target_delete_count = %s,
               target_total_affected_count = %s,
               file_write_row_count = %s,
               target_file_path = %s,
               status = 'SUCCESS',
               error_message = '',
               end_tm = CURRENT_TIMESTAMP,
               update_tm = CURRENT_TIMESTAMP
         WHERE run_hist_id = %s
    """
    hook.run(update_sql, parameters=(
        extract_row_count, stg_load_row_count, target_insert_count,
        target_update_count, target_delete_count, total_affected,
        file_write_row_count, target_file_path or "", run_hist_id,
    ))


# ****** standalone + airflow 전용 ******
def update_etl_run_hist_failed(
    run_hist_id: int,
    error_message: str,
    extract_row_count: int = 0,
    stg_load_row_count: int = 0,
    target_insert_count: int = 0,
    target_update_count: int = 0,
    target_delete_count: int = 0,
    file_write_row_count: int = 0,
    target_file_path: str | None = None,
    meta_conn_id: str = DEFAULT_META_POSTGRES_CONN_ID,
) -> None:
    hook = get_meta_db_hook(meta_conn_id)
    total_affected = int(target_insert_count) + int(target_update_count) + int(target_delete_count)
    update_sql = f"""
        UPDATE {HIST_TABLE_NAME}
           SET extract_row_count = %s,
               stg_load_row_count = %s,
               target_insert_count = %s,
               target_update_count = %s,
               target_delete_count = %s,
               target_total_affected_count = %s,
               file_write_row_count = %s,
               target_file_path = %s,
               status = 'FAILED',
               error_message = %s,
               end_tm = CURRENT_TIMESTAMP,
               update_tm = CURRENT_TIMESTAMP
         WHERE run_hist_id = %s
    """
    hook.run(update_sql, parameters=(
        extract_row_count, stg_load_row_count, target_insert_count,
        target_update_count, target_delete_count, total_affected,
        file_write_row_count, target_file_path or "", cut_text(error_message, 4000),
        run_hist_id,
    ))


# ****** standalone + airflow 전용 ******
def parse_csv_columns(raw_value: str | None) -> list[str]:
    if raw_value is None:
        return []

    return [c.strip() for c in raw_value.split(",") if c and c.strip()]



# ****** standalone + airflow 전용 ******
def parse_column_mapping(raw_mapping: str | None) -> dict[str, str]:
    if raw_mapping is None:
        return {}

    raw_mapping = raw_mapping.strip()
    if not raw_mapping:
        return {}

    try:
        parsed = json.loads(raw_mapping)

        if isinstance(parsed, dict):
            result = {}
            for k, v in parsed.items():
                src = str(k).strip()
                tgt = str(v).strip()

                if not src or not tgt:
                    raise ValueError(
                        f"Invalid column_mapping JSON entry: {k}:{v}"
                    )

                result[src] = tgt

            return result

        if isinstance(parsed, list):
            result = {}
            for item in parsed:
                if not isinstance(item, dict):
                    raise ValueError(
                        f"Invalid column_mapping JSON list item: {item}"
                    )

                if "source" not in item or "target" not in item:
                    raise ValueError(
                        f"Invalid column_mapping JSON list item: {item}"
                    )

                src = str(item["source"]).strip()
                tgt = str(item["target"]).strip()

                if not src or not tgt:
                    raise ValueError(
                        f"Invalid column_mapping JSON list item: {item}"
                    )

                result[src] = tgt

            return result

    except json.JSONDecodeError:
        pass

    result = {}

    for pair in raw_mapping.split(","):
        pair = pair.strip()
        if not pair:
            continue

        if ":" in pair:
            src, tgt = pair.split(":", 1)
        elif "=" in pair:
            src, tgt = pair.split("=", 1)
        else:
            raise ValueError(
                f"Invalid column_mapping format: {raw_mapping}"
            )

        src = src.strip()
        tgt = tgt.strip()

        if not src or not tgt:
            raise ValueError(
                f"Invalid column_mapping pair: {pair}"
            )

        result[src] = tgt

    return result



# ****** standalone + airflow 전용 ******
def parse_input_params(raw_input_param: str | None) -> dict[str, str]:
    if raw_input_param is None:
        return {}

    raw_input_param = raw_input_param.strip()
    if not raw_input_param:
        return {}

    try:
        parsed = json.loads(raw_input_param)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid input_param JSON: {raw_input_param}") from e

    if not isinstance(parsed, dict):
        raise ValueError(
            f"input_param must be JSON object(dict): {raw_input_param}"
        )

    result = {}
    for k, v in parsed.items():
        key = str(k).strip()
        val = "" if v is None else str(v)

        if not key:
            raise ValueError(f"Invalid input_param key: {k}")

        result[key] = val

    return result



# ****** standalone + airflow 전용 ******
def parse_config_option(raw_config_option: str | None) -> dict[str, str]:
    if raw_config_option is None:
        return {}

    raw_config_option = raw_config_option.strip()
    if not raw_config_option:
        return {}

    try:
        parsed = json.loads(raw_config_option)
    except json.JSONDecodeError as e:
        raise ValueError(
            f"Invalid config_option JSON: {raw_config_option}"
        ) from e

    if not isinstance(parsed, dict):
        raise ValueError(
            f"config_option must be JSON object(dict): {raw_config_option}"
        )

    result = {}
    for k, v in parsed.items():
        key = str(k).strip()
        val = "" if v is None else str(v).strip()

        if not key:
            raise ValueError(f"Invalid config_option key: {k}")

        result[key] = val

    return result



# ****** standalone + airflow 전용 ******
def apply_input_params(sql_text: str | None, input_params: dict[str, str]) -> str:
    if sql_text is None:
        return ""

    result = sql_text.strip()
    if not result:
        return ""

    if not input_params:
        return result

    for key in sorted(input_params.keys(), key=len, reverse=True):
        result = result.replace(key, input_params[key])

    return result



# ****** standalone + airflow 전용 ******
def build_limit_0_sql(source_exec_sql: str) -> str:
    return f"""
        SELECT *
        FROM (
            {source_exec_sql}
        ) q
        LIMIT 0
    """



# ****** standalone + airflow 전용 ******
def get_single_table_config(
    dag_id: str,
    task_name: str,
    meta_postgres_conn_id: str = META_POSTGRES_CONN_ID,
    today_dt: str | None = None,
) -> dict:
    """
    dag_id + task_name 湲곗??쇰줈 ETL 硫뷀? 1嫄대쭔 議고쉶?쒕떎.
    dynamic expand??list媛 ?꾨땲??static task??dict 1嫄댁쓣 諛섑솚?쒕떎.
    """

    if not today_dt:
        raise ValueError("today_dt is required")

    meta_hook = get_meta_db_hook(meta_postgres_conn_id)

    insert_etl_param_sql = """
    INSERT INTO ETL_PARAM
    WITH BASE_PARAM AS
    (
    SELECT
    YESTERDAY_DT AS P_BASE_DT
    , yyyy || mm || '01' AS P_START_DT
    , YESTERDAY_DT AS P_END_DT
    , BEF_MAX_DAY AS P_BEF_MAX_DT
    , MAX_DAY AS P_MAX_DT
    , yyyy || mm as P_BASE_YM
    FROM ETL_CALENDAR
    WHERE 1=1
    AND TODAY_DT = %s
    )
    SELECT
    DAG_ID
    , TASK_NAME
    , '{"$$P_BASE_DT":"' || P_BASE_DT ||
    '","$$P_START_DT":"' || P_START_DT ||
    '","$$P_END_DT":"' || P_END_DT ||
    '","$$P_START_TM":"' || (INPUT_PARAM::JSON ->> '$$P_END_TM') ||
    '","$$P_END_TM":"' || TO_CHAR(TIMEZONE('ASIA/SEOUL', NOW())::TIMESTAMP, 'YYYYMMDDHH24MISS') ||
    '","$$P_BEF_MAX_DT":"' || P_BEF_MAX_DT ||
    '","$$P_MAX_DT":"' || P_MAX_DT ||
    '","$$P_BASE_YM":"' || P_BASE_YM ||
    '"}' AS TOBE_PARAM
    , A.INPUT_PARAM AS ASIS_PARAM
    , TIMEZONE('ASIA/SEOUL', NOW())::TIMESTAMP AS CREATED_TM
    , 'AIRFLOW' AS CREATE_USER_ID
    FROM etl_meta_db_to_db A, BASE_PARAM B
    WHERE 1=1
    AND DAG_ID = %s
    AND TASK_NAME = %s
    AND DISABLE_DT = '20991231'
    AND ENABLE_YN = 'Y'
    """

    insert_etl_param_redshift_sql = """
    INSERT INTO ETL_PARAM
    WITH BASE_PARAM AS
    (
    SELECT
    YESTERDAY_DT AS P_BASE_DT
    , yyyy || mm || '01' AS P_START_DT
    , YESTERDAY_DT AS P_END_DT
    , BEF_MAX_DAY AS P_BEF_MAX_DT
    , MAX_DAY AS P_MAX_DT
    , yyyy || mm as P_BASE_YM
    FROM ETL_CALENDAR
    WHERE 1=1
    AND TODAY_DT = %s
    )
    SELECT
    DAG_ID
    , TASK_NAME
    , '{"$$P_BASE_DT":"' || P_BASE_DT ||
    '","$$P_START_DT":"' || P_START_DT ||
    '","$$P_END_DT":"' || P_END_DT ||
    '","$$P_START_TM":"' || JSON_EXTRACT_PATH_TEXT(INPUT_PARAM, '$$P_END_TM') ||
    '","$$P_END_TM":"' || TO_CHAR(CONVERT_TIMEZONE('Asia/Seoul', GETDATE()), 'YYYYMMDDHH24MISS') ||
    '","$$P_BEF_MAX_DT":"' || P_BEF_MAX_DT ||
    '","$$P_MAX_DT":"' || P_MAX_DT ||
    '","$$P_BASE_YM":"' || P_BASE_YM ||
    '"}' AS TOBE_PARAM
    , A.INPUT_PARAM AS ASIS_PARAM
    , CONVERT_TIMEZONE('Asia/Seoul', GETDATE()) AS CREATED_TM
    , 'AIRFLOW' AS CREATE_USER_ID
    FROM etl_meta_db_to_db A, BASE_PARAM B
    WHERE 1=1
    AND DAG_ID = %s
    AND TASK_NAME = %s
    AND DISABLE_DT = '20991231'
    AND ENABLE_YN = 'Y'
    """

    update_input_param_sql = """
    UPDATE etl_meta_db_to_db a
    SET input_param = b.tobe_param
    FROM (
        SELECT dag_id, task_name, tobe_param
        FROM etl_param a
        WHERE dag_id = %s
          AND task_name = %s
          AND (task_name, created_tm) = (
                SELECT b.task_name, b.created_tm
                FROM (
                    SELECT dag_id, task_name, created_tm
                    FROM etl_param
                    WHERE dag_id = a.dag_id
                      AND task_name = a.task_name
                    ORDER BY created_tm DESC
                ) b
                LIMIT 1
          )
    ) b
    WHERE a.dag_id = b.dag_id
      AND a.task_name = b.task_name
    """

    update_input_param_redshift_sql = """
    UPDATE etl_meta_db_to_db
    SET input_param = b.tobe_param
    FROM (
        SELECT dag_id, task_name, tobe_param
        FROM (
            SELECT
                dag_id,
                task_name,
                tobe_param,
                ROW_NUMBER() OVER (
                    PARTITION BY dag_id, task_name
                    ORDER BY created_tm DESC
                ) AS rn
            FROM etl_param
            WHERE dag_id = %s
              AND task_name = %s
        ) x
        WHERE rn = 1
    ) b
    WHERE etl_meta_db_to_db.dag_id = b.dag_id
      AND etl_meta_db_to_db.task_name = b.task_name
    """

    select_meta_sql = """
    SELECT
        task_name,
        COALESCE(exec_seq, 999999) AS exec_seq,
        source_table,
        target_table,
        pk_column,
        source_exec_sql,
        column_mapping,
        load_option,
        stg_drop_yn,
        target_pre_sql,
        target_post_sql,
        config_option,
        input_param
    FROM etl_meta_db_to_db
    WHERE enable_yn = 'Y'
      AND dag_id = %s
      AND task_name = %s
      AND disable_dt = '20991231'
    """

    conn = None
    cursor = None

    try:
        conn = meta_hook.get_conn()
        conn.autocommit = False
        cursor = conn.cursor()

        if USE_AIRFLOW_HOOKS:
            cursor.execute("SET TIME ZONE 'Asia/Seoul'")
            cursor.execute(insert_etl_param_sql, (today_dt, dag_id, task_name))
            cursor.execute(update_input_param_sql, (dag_id, task_name))
        else:
            cursor.execute(insert_etl_param_redshift_sql, (today_dt, dag_id, task_name))
            cursor.execute(update_input_param_redshift_sql, (dag_id, task_name))
        cursor.execute(select_meta_sql, (dag_id, task_name))
        rows = cursor.fetchall()

        conn.commit()

    except Exception:
        if conn is not None:
            conn.rollback()
        raise

    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()

    if not rows:
        raise ValueError(
            f"ETL meta not found. dag_id={dag_id}, task_name={task_name}"
        )

    if len(rows) > 1:
        raise ValueError(
            f"ETL meta must be unique. dag_id={dag_id}, task_name={task_name}, count={len(rows)}"
        )

    r = rows[0]

    meta_task_name = (r[0] or "").strip() if r[0] is not None else ""
    exec_seq = int(r[1]) if r[1] is not None else 999999

    source_table = (r[2] or "").strip() if r[2] is not None else ""
    target_table = (r[3] or "").strip() if r[3] is not None else ""
    pk_columns = parse_csv_columns(r[4])
    source_exec_sql = (r[5] or "").strip() if r[5] is not None else ""
    column_mapping = r[6]
    load_option = (r[7] or "di").strip().lower() if r[7] is not None else "di"
    stg_drop_yn = (r[8] or "N").strip().upper() if r[8] is not None else "N"
    target_pre_sql = (r[9] or "").strip() if r[9] is not None else ""
    target_post_sql = (r[10] or "").strip() if r[10] is not None else ""
    config_option = (r[11] or "").strip() if r[11] is not None else ""
    input_param = (r[12] or "").strip() if r[12] is not None else ""

    if not meta_task_name:
        meta_task_name = task_name

    if not target_table:
        raise ValueError("etl_meta.target_table is empty")

    if not source_exec_sql:
        raise ValueError(f"{target_table}: source_exec_sql is empty")

    if load_option not in ("ui", "di", "ti", "i", "u", "d"):
        raise ValueError(
            f"{target_table}: invalid load_option [{load_option}]"
        )

    if stg_drop_yn not in ("Y", "N"):
        raise ValueError(
            f"{target_table}: invalid stg_drop_yn [{stg_drop_yn}]"
        )

    if load_option in ("ui", "di", "u", "d") and not pk_columns:
        raise ValueError(
            f"{target_table}: pk_column is required for load_option [{load_option}]"
        )

    parsed_config_option = parse_config_option(config_option)

    source_conn_name = (
        parsed_config_option.get("SOURCE_CONN_NAME") or ""
    ).strip()

    target_conn_name = (
        parsed_config_option.get("TARGET_CONN_NAME") or ""
    ).strip()

    if not source_conn_name:
        raise ValueError(
            f"{target_table}: config_option.SOURCE_CONN_NAME is empty"
        )

    if not target_conn_name:
        raise ValueError(
            f"{target_table}: config_option.TARGET_CONN_NAME is empty"
        )

    return {
        "task_name": meta_task_name,
        "exec_seq": exec_seq,
        "source_table": source_table,
        "target_table": target_table,
        "pk_columns": pk_columns,
        "source_exec_sql": source_exec_sql,
        "column_mapping": column_mapping,
        "load_option": load_option,
        "stg_drop_yn": stg_drop_yn,
        "target_pre_sql": target_pre_sql,
        "target_post_sql": target_post_sql,
        "config_option": parsed_config_option,
        "input_param": input_param,
        "source_conn_name": source_conn_name,
        "target_conn_name": target_conn_name,
    }



# ****** standalone + airflow 전용 ******
def run_vertica_to_redshift_etl(
    dag_id: str,
    task_name: str,
    meta_postgres_conn_id: str = META_POSTGRES_CONN_ID,
    chunk_size: int = CHUNK_SIZE,
    **context,
):
    """
    static task?먯꽌 吏곸젒 ?몄텧?섎뒗 ?ㅼ젣 ETL 怨듯넻 ?⑥닔.
    dag_id + task_name 湲곗??쇰줈 硫뷀? 1嫄?議고쉶 ??ETL ?섑뻾.
    """

    runtime_info = get_task_runtime_info(**context)

    table_config = get_single_table_config(
        dag_id=dag_id,
        task_name=task_name,
        meta_postgres_conn_id=meta_postgres_conn_id,
    )

    meta_task_name = (table_config.get("task_name") or "").strip()
    exec_seq = table_config.get("exec_seq")

    source_table = (table_config.get("source_table") or "").strip()
    target_table = (table_config.get("target_table") or "").strip()
    pk_columns = table_config.get("pk_columns") or []
    raw_source_exec_sql = (table_config.get("source_exec_sql") or "").strip()
    raw_column_mapping = table_config.get("column_mapping")
    load_option = (table_config.get("load_option") or "di").strip().lower()
    stg_drop_yn = (table_config.get("stg_drop_yn") or "N").strip().upper()
    raw_target_pre_sql = (table_config.get("target_pre_sql") or "").strip()
    raw_target_post_sql = (table_config.get("target_post_sql") or "").strip()
    config_option = table_config.get("config_option") or {}
    raw_input_param = table_config.get("input_param")
    source_conn_name = (table_config.get("source_conn_name") or "").strip()
    target_conn_name = (table_config.get("target_conn_name") or "").strip()

    print(
        f"START ETL "
        f"dag_id={dag_id}, "
        f"task_name={meta_task_name}, "
        f"exec_seq={exec_seq}, "
        f"source_table={source_table}, "
        f"target_table={target_table}"
    )

    run_hist_id = None
    extract_row_count = 0
    stg_load_row_count = 0
    target_insert_count = 0
    target_update_count = 0
    target_delete_count = 0
    file_write_row_count = 0
    target_file_path = ""

    try:
        run_hist_id = insert_etl_run_hist(
            dag_id=dag_id,
            run_id=runtime_info["run_id"],
            task_id=meta_task_name or runtime_info["task_id"],
            map_index=runtime_info["map_index"],
            source_table=source_table,
            target_table=target_table,
            load_option=load_option,
            source_conn_name=source_conn_name,
            target_conn_name=target_conn_name,
            input_param=raw_input_param,
            config_option={
                **config_option,
                "AIRFLOW_TASK_ID": runtime_info["task_id"],
                "TASK_NAME": meta_task_name,
                "EXEC_SEQ": str(exec_seq),
            },
            meta_conn_id=meta_postgres_conn_id,
        )

        input_params = parse_input_params(raw_input_param)

        source_exec_sql = apply_input_params(
            raw_source_exec_sql,
            input_params,
        )

        target_pre_sql = apply_input_params(
            raw_target_pre_sql,
            input_params,
        )

        target_post_sql = apply_input_params(
            raw_target_post_sql,
            input_params,
        )

        stg_table = f"stg_{target_table}"

        create_stg_sql = f"""
            CREATE TABLE IF NOT EXISTS {stg_table}
            (LIKE {target_table} INCLUDING ALL)
        """

        truncate_stg_sql = f"TRUNCATE TABLE {stg_table}"
        truncate_target_sql = f"TRUNCATE TABLE {target_table}"
        drop_stg_sql = f"DROP TABLE IF EXISTS {stg_table}"

        source_hook = get_vertica_hook(source_conn_name)
        target_hook = get_redshift_hook(target_conn_name)

        source_conn = None
        meta_cursor = None
        source_cursor = None
        target_tx_conn = None
        target_tx_cursor = None

        job_succeeded = False

        try:
            target_hook.run(create_stg_sql)
            target_hook.run(truncate_stg_sql)

            source_conn = source_hook.get_conn()

            meta_cursor = source_conn.cursor()
            meta_sql = build_limit_0_sql(source_exec_sql)
            meta_cursor.execute(meta_sql)

            if meta_cursor.description is None:
                raise ValueError(
                    f"{target_table}: source_exec_sql did not return a result set. "
                    f"Only SELECT query is allowed. source_exec_sql=[{source_exec_sql}]"
                )

            source_columns = [desc[0] for desc in meta_cursor.description]

            if not source_columns:
                raise ValueError(
                    f"{target_table}: source_exec_sql returned no columns."
                )

            column_mapping = parse_column_mapping(raw_column_mapping) or {}

            target_columns = [
                column_mapping.get(src_col, src_col)
                for src_col in source_columns
            ]

            if len(set(target_columns)) != len(target_columns):
                raise ValueError(
                    f"{target_table}: duplicate target columns detected after mapping. "
                    f"source_columns={source_columns}, target_columns={target_columns}"
                )

            missing_pk_columns = [
                pk for pk in pk_columns if pk not in target_columns
            ]

            if missing_pk_columns:
                raise ValueError(
                    f"{target_table}: mapped result does not include PK columns: "
                    f"{missing_pk_columns}"
                )

            insert_columns_sql = ", ".join(target_columns)
            select_columns_sql = ", ".join(
                [f"s.{col}" for col in target_columns]
            )

            insert_sql = f"""
                INSERT INTO {target_table} ({insert_columns_sql})
                SELECT {select_columns_sql}
                FROM {stg_table} s
            """

            pk_join_condition_sql = " AND ".join(
                [f"t.{pk} = s.{pk}" for pk in pk_columns]
            )

            non_pk_columns = [
                c for c in target_columns if c not in pk_columns
            ]

            if non_pk_columns:
                update_set_sql = ", ".join(
                    [f"{col} = s.{col}" for col in non_pk_columns]
                )

                update_sql = f"""
                    UPDATE {target_table} t
                    SET {update_set_sql}
                    FROM {stg_table} s
                    WHERE {pk_join_condition_sql}
                """
            else:
                update_sql = None

            not_exists_condition_sql = " AND ".join(
                [f"t.{pk} = s.{pk}" for pk in pk_columns]
            )

            insert_not_exists_sql = f"""
                INSERT INTO {target_table} ({insert_columns_sql})
                SELECT {select_columns_sql}
                FROM {stg_table} s
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM {target_table} t
                    WHERE {not_exists_condition_sql}
                )
            """

            delete_sql = f"""
                DELETE FROM {target_table} t
                WHERE EXISTS (
                    SELECT 1
                    FROM {stg_table} s
                    WHERE {pk_join_condition_sql}
                )
            """

            source_cursor = source_conn.cursor()
            if hasattr(source_cursor, "itersize"):
                source_cursor.itersize = chunk_size
            source_cursor.execute(source_exec_sql)

            while True:
                rows = source_cursor.fetchmany(size=chunk_size)

                if not rows:
                    break

                target_hook.insert_rows(
                    table=stg_table,
                    rows=rows,
                    target_fields=target_columns,
                    commit_every=chunk_size,
                    executemany=True,
                )

                extract_row_count += len(rows)
                stg_load_row_count += len(rows)

                print(
                    f"dag_id={dag_id}, "
                    f"task_name={meta_task_name}, "
                    f"exec_seq={exec_seq}, "
                    f"{source_table or '[source_sql]'} -> {stg_table} "
                    f"chunk={len(rows)} total={stg_load_row_count}"
                )

            if stg_load_row_count > 0:
                target_tx_conn = target_hook.get_conn()
                if hasattr(target_tx_conn, "autocommit"):
                    target_tx_conn.autocommit = False
                target_tx_cursor = target_tx_conn.cursor()

                try:
                    if target_pre_sql:
                        target_tx_cursor.execute(target_pre_sql)
                        print(f"{target_table} target_pre_sql completed")

                    if load_option == "ui":
                        if update_sql:
                            target_tx_cursor.execute(update_sql)
                            target_update_count = target_tx_cursor.rowcount
                            print(f"{target_table} UPDATE completed")

                        target_tx_cursor.execute(insert_not_exists_sql)
                        target_insert_count = target_tx_cursor.rowcount
                        print(f"{target_table} INSERT completed (UI)")

                    elif load_option == "di":
                        target_tx_cursor.execute(delete_sql)
                        target_delete_count = target_tx_cursor.rowcount
                        print(f"{target_table} DELETE completed")

                        target_tx_cursor.execute(insert_sql)
                        target_insert_count = target_tx_cursor.rowcount
                        print(f"{target_table} INSERT completed (DI)")

                    elif load_option == "ti":
                        target_tx_cursor.execute(truncate_target_sql)
                        print(f"{target_table} TRUNCATE completed")

                        target_tx_cursor.execute(insert_sql)
                        target_insert_count = target_tx_cursor.rowcount
                        print(f"{target_table} INSERT completed (TI)")

                    elif load_option == "i":
                        target_tx_cursor.execute(insert_sql)
                        target_insert_count = target_tx_cursor.rowcount
                        print(f"{target_table} INSERT completed (I)")

                    elif load_option == "u":
                        if update_sql:
                            target_tx_cursor.execute(update_sql)
                            target_update_count = target_tx_cursor.rowcount
                            print(f"{target_table} UPDATE completed (U)")
                        else:
                            print(
                                f"{target_table}: no non-pk columns to update, UPDATE skipped"
                            )

                    elif load_option == "d":
                        target_tx_cursor.execute(delete_sql)
                        target_delete_count = target_tx_cursor.rowcount
                        print(f"{target_table} DELETE completed (D)")

                    if target_post_sql:
                        target_tx_cursor.execute(target_post_sql)
                        print(f"{target_table} target_post_sql completed")

                    target_tx_conn.commit()
                    job_succeeded = True

                except Exception:
                    target_tx_conn.rollback()
                    raise

            else:
                print(f"{target_table}: no rows fetched, target load skipped")
                job_succeeded = True

        finally:
            if meta_cursor is not None:
                meta_cursor.close()

            if source_cursor is not None:
                source_cursor.close()

            if source_conn is not None:
                source_conn.close()

            if target_tx_cursor is not None:
                target_tx_cursor.close()

            if target_tx_conn is not None:
                target_tx_conn.close()

            if job_succeeded and stg_drop_yn == "Y":
                target_hook.run(drop_stg_sql)
                print(f"{stg_table} dropped")
            else:
                print(
                    f"{stg_table} kept "
                    f"(job_succeeded={job_succeeded}, stg_drop_yn={stg_drop_yn})"
                )

        update_etl_run_hist_success(
            run_hist_id=run_hist_id,
            extract_row_count=extract_row_count,
            stg_load_row_count=stg_load_row_count,
            target_insert_count=target_insert_count,
            target_update_count=target_update_count,
            target_delete_count=target_delete_count,
            file_write_row_count=file_write_row_count,
            target_file_path=target_file_path,
            meta_conn_id=meta_postgres_conn_id,
        )

        print(
            f"END ETL SUCCESS "
            f"dag_id={dag_id}, "
            f"task_name={meta_task_name}, "
            f"exec_seq={exec_seq}, "
            f"source_table={source_table}, "
            f"target_table={target_table}"
        )

    except Exception:
        print(
            f"END ETL FAILED "
            f"dag_id={dag_id}, "
            f"task_name={task_name}, "
            f"source_table={source_table}, "
            f"target_table={target_table}"
        )

        if run_hist_id is not None:
            update_etl_run_hist_failed(
                run_hist_id=run_hist_id,
                error_message=traceback.format_exc(),
                extract_row_count=extract_row_count,
                stg_load_row_count=stg_load_row_count,
                target_insert_count=target_insert_count,
                target_update_count=target_update_count,
                target_delete_count=target_delete_count,
                file_write_row_count=file_write_row_count,
                target_file_path=target_file_path,
                meta_conn_id=meta_postgres_conn_id,
            )

        raise



# ****** airflow 전용 ******
def create_vertica_to_redshift_task(
    dag_id: str,
    task_name: str,
    task_id: str | None = None,
    meta_postgres_conn_id: str = META_POSTGRES_CONN_ID,
    chunk_size: int = CHUNK_SIZE,
    today_dt: str | None = None,
):
    """
    static Airflow task ?앹꽦 ?⑥닔.

    task_name:
        etl_meta_db_to_db.task_name 媛?

    task_id:
        Airflow UI???쒖떆??task_id.
        ?앸왂?섎㈃ task_name??洹몃?濡??ъ슜?쒕떎.
    """

    if airflow_task is None:
        raise RuntimeError(
            "create_vertica_to_redshift_task() requires Airflow. "
            "Use this file as a CLI script for standalone Python execution."
        )

    airflow_task_id = task_id or task_name

    @airflow_task(task_id=airflow_task_id)
    def _static_etl_task(**context):
        run_vertica_to_redshift_etl(
            dag_id=dag_id,
            task_name=task_name,
            meta_postgres_conn_id=meta_postgres_conn_id,
            chunk_size=chunk_size,
            today_dt=today_dt,
            **context,
        )

    return _static_etl_task()
# ****** standalone 전용 ******
def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run static Vertica to Redshift ETL without Airflow."
    )
    parser.add_argument("--dag-id", required=True, help="etl_meta_db_to_db.dag_id")
    parser.add_argument("--task-name", required=True, help="etl_meta_db_to_db.task_name")
    parser.add_argument("--today-dt", required=True, help="ETL_CALENDAR.TODAY_DT")
    parser.add_argument(
        "--meta-conn-id",
        "--meta-postgres-conn-id",
        dest="meta_postgres_conn_id",
        default=META_POSTGRES_CONN_ID,
        help=(
            "Metadata DB connection id. "
            "Airflow uses Postgres, standalone uses Redshift. "
            "Default: postgres_conn"
        ),
    )
    parser.add_argument(
        "--chunk-size",
        type=int,
        default=CHUNK_SIZE,
        help="Fetch/insert chunk size. Default: 5000",
    )
    parser.add_argument(
        "--run-id",
        default=None,
        help="Optional run id for etl_job_run_dtl_hist.",
    )
    parser.add_argument(
        "--task-id",
        default=None,
        help="Optional task id for etl_job_run_dtl_hist.",
    )
    parser.add_argument(
        "--map-index",
        type=int,
        default=-1,
        help="Optional map index for etl_job_run_dtl_hist.",
    )
    return parser


# ****** standalone 전용 ******
def main(argv: list[str] | None = None) -> int:
    global USE_AIRFLOW_HOOKS
    USE_AIRFLOW_HOOKS = False
    args = build_arg_parser().parse_args(argv)
    run_vertica_to_redshift_etl(
        dag_id=args.dag_id,
        task_name=args.task_name,
        meta_postgres_conn_id=args.meta_postgres_conn_id,
        chunk_size=args.chunk_size,
        today_dt=args.today_dt,
        run_id=args.run_id,
        task_id=args.task_id or args.task_name,
        map_index=args.map_index,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


