﻿from __future__ import annotations

import argparse
import csv
import json
import os
import subprocess
import traceback
import uuid
from datetime import datetime
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

try:
    from airflow.decorators import task as airflow_task
    from airflow.providers.postgres.hooks.postgres import (
        PostgresHook as AirflowPostgresHook,
    )
except ImportError:
    airflow_task = None
    AirflowPostgresHook = None

try:
    import psycopg2
except ImportError:
    psycopg2 = None


DEFAULT_META_POSTGRES_CONN_ID = "postgres_conn"
HIST_TABLE_NAME = "etl_job_run_dtl_hist"
USE_AIRFLOW_HOOKS = True
# ****** standalone 전용 ******
def build_airflow_conn_env_name(conn_id: str) -> str:
    normalized = "".join(
        ch if ch.isalnum() else "_"
        for ch in conn_id.upper()
    )
    return f"AIRFLOW_CONN_{normalized}"


# ****** standalone 전용 ******
def parse_postgres_conn_uri(conn_id: str, uri: str) -> dict:
    parsed = urlparse(uri)
    if parsed.scheme not in ("postgres", "postgresql"):
        raise ValueError(
            f"{conn_id}: unsupported connection URI scheme "
            f"[{parsed.scheme}]. Use postgres:// or postgresql://."
        )

    query = parse_qs(parsed.query)
    conn_kwargs = {
        "host": parsed.hostname,
        "port": parsed.port or 5432,
        "dbname": unquote(parsed.path.lstrip("/")),
        "user": unquote(parsed.username or ""),
        "password": unquote(parsed.password or ""),
    }

    for key, values in query.items():
        if values:
            conn_kwargs[key] = values[-1]

    return {k: v for k, v in conn_kwargs.items() if v not in (None, "")}


# ****** standalone 전용 ******
def get_env_value(conn_id: str, suffix: str, default: str = "") -> str:
    prefix = "".join(ch if ch.isalnum() else "_" for ch in conn_id.upper())
    return os.getenv(f"{prefix}_{suffix}", default)


# ****** standalone 전용 ******
def build_postgres_conn_kwargs_from_env(conn_id: str) -> dict:
    airflow_conn_uri = os.getenv(build_airflow_conn_env_name(conn_id))
    if airflow_conn_uri:
        return parse_postgres_conn_uri(conn_id, airflow_conn_uri)

    kwargs = {
        "host": get_env_value(conn_id, "HOST"),
        "port": get_env_value(conn_id, "PORT", "5432"),
        "dbname": (
            get_env_value(conn_id, "DBNAME")
            or get_env_value(conn_id, "DATABASE")
        ),
        "user": get_env_value(conn_id, "USER"),
        "password": get_env_value(conn_id, "PASSWORD"),
    }

    extra_raw = get_env_value(conn_id, "EXTRA")
    if extra_raw:
        extra = json.loads(extra_raw)
        if not isinstance(extra, dict):
            raise ValueError(f"{conn_id}_EXTRA must be JSON object")
        kwargs.update(extra)

    missing = [key for key in ("host", "dbname", "user") if not kwargs.get(key)]
    if missing:
        env_name = build_airflow_conn_env_name(conn_id)
        raise ValueError(
            f"Postgres connection [{conn_id}] is not configured. "
            f"Set {env_name}=postgresql://user:password@host:5432/dbname "
            f"or set {conn_id.upper()}_HOST, _DBNAME, _USER, _PASSWORD. "
            f"Missing: {missing}"
        )

    return {k: v for k, v in kwargs.items() if v not in (None, "")}


# ****** standalone 전용 ******
class StandalonePostgresHook:
    def __init__(self, postgres_conn_id: str):
        self.postgres_conn_id = postgres_conn_id

    def get_conn(self):
        if psycopg2 is None:
            raise ImportError(
                "psycopg2 is required for standalone Python execution. "
                "Install it with: pip install psycopg2-binary"
            )
        return psycopg2.connect(
            **build_postgres_conn_kwargs_from_env(self.postgres_conn_id)
        )

    def run(self, sql: str, parameters=None) -> None:
        conn = None
        cursor = None
        try:
            conn = self.get_conn()
            conn.autocommit = False
            cursor = conn.cursor()
            cursor.execute(sql, parameters)
            conn.commit()
        except Exception:
            if conn is not None:
                conn.rollback()
            raise
        finally:
            if cursor is not None:
                cursor.close()
            if conn is not None:
                conn.close()

    def get_first(self, sql: str, parameters=None):
        conn = None
        cursor = None
        try:
            conn = self.get_conn()
            cursor = conn.cursor()
            cursor.execute(sql, parameters)
            return cursor.fetchone()
        finally:
            if cursor is not None:
                cursor.close()
            if conn is not None:
                conn.close()

    def insert_rows(
        self,
        table: str,
        rows: list[tuple],
        target_fields: list[str] | None = None,
        commit_every: int = 1000,
        executemany: bool = False,
    ) -> None:
        if not rows:
            return

        fields_sql = ""
        if target_fields:
            fields_sql = " (" + ", ".join(target_fields) + ")"

        placeholders = ", ".join(["%s"] * len(rows[0]))
        insert_sql = f"INSERT INTO {table}{fields_sql} VALUES ({placeholders})"

        conn = None
        cursor = None
        try:
            conn = self.get_conn()
            conn.autocommit = False
            cursor = conn.cursor()
            if executemany:
                cursor.executemany(insert_sql, rows)
            else:
                for row in rows:
                    cursor.execute(insert_sql, row)
            conn.commit()
        except Exception:
            if conn is not None:
                conn.rollback()
            raise
        finally:
            if cursor is not None:
                cursor.close()
            if conn is not None:
                conn.close()


# ****** standalone + airflow 전용 ******
def get_postgres_hook(postgres_conn_id: str):
    if USE_AIRFLOW_HOOKS and AirflowPostgresHook is not None:
        return AirflowPostgresHook(postgres_conn_id=postgres_conn_id)
    return StandalonePostgresHook(postgres_conn_id=postgres_conn_id)


# ****** standalone + airflow 전용 ******
def safe_json_dumps(value) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, default=str)


# ****** standalone + airflow 전용 ******
def cut_text(value: str | None, max_length: int = 4000) -> str:
    if value is None:
        return ""
    text = str(value)
    if len(text) <= max_length:
        return text
    return text[:max_length]


# ****** standalone + airflow 전용 ******
def get_task_runtime_info(**context) -> dict:
    ti = context.get("ti")
    task = context.get("task")
    task_id = context.get("task_id") or getattr(task, "task_id", "standalone_task")
    run_id = context.get("run_id") or f"manual__{datetime.now():%Y%m%dT%H%M%S}__{uuid.uuid4().hex[:8]}"

    return {
        "run_id": run_id,
        "task_id": task_id,
        "map_index": context.get("map_index", getattr(ti, "map_index", -1)),
    }


# ****** standalone + airflow 전용 ******
def insert_etl_run_hist(
    dag_id: str,
    run_id: str | None,
    task_id: str | None,
    map_index: int | None,
    source_table: str | None,
    target_table: str | None,
    load_option: str | None = None,
    source_conn_name: str | None = None,
    target_conn_name: str | None = None,
    input_param=None,
    config_option=None,
    create_user_id: str = "python",
    meta_conn_id: str = DEFAULT_META_POSTGRES_CONN_ID,
) -> int:
    hook = get_postgres_hook(meta_conn_id)
    insert_sql = f"""
        INSERT INTO {HIST_TABLE_NAME} (
            dag_id, run_id, task_id, map_index, source_table, target_table,
            load_option, source_conn_name, target_conn_name,
            extract_row_count, stg_load_row_count, target_insert_count,
            target_update_count, target_delete_count,
            target_total_affected_count, file_write_row_count,
            target_file_path, status, error_message, start_tm, end_tm,
            input_param, config_option, create_user_id, create_tm, update_tm
        )
        VALUES (
            %s, %s, %s, %s, %s, %s, %s, %s, %s,
            0, 0, 0, 0, 0, 0, 0, '',
            'RUNNING', '', NOW(), NULL,
            %s, %s, %s, NOW(), NOW()
        )
        RETURNING run_hist_id
    """

    conn = None
    cursor = None
    try:
        conn = hook.get_conn()
        conn.autocommit = False
        cursor = conn.cursor()
        cursor.execute(
            insert_sql,
            (
                dag_id, run_id, task_id, map_index, source_table or "",
                target_table or "", load_option or "", source_conn_name or "",
                target_conn_name or "", safe_json_dumps(input_param),
                safe_json_dumps(config_option), create_user_id,
            ),
        )
        run_hist_id = cursor.fetchone()[0]
        conn.commit()
        return run_hist_id
    except Exception:
        if conn is not None:
            conn.rollback()
        raise
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()


# ****** standalone + airflow 전용 ******
def update_etl_run_hist_success(
    run_hist_id: int,
    extract_row_count: int = 0,
    stg_load_row_count: int = 0,
    target_insert_count: int = 0,
    target_update_count: int = 0,
    target_delete_count: int = 0,
    file_write_row_count: int = 0,
    target_file_path: str | None = None,
    meta_conn_id: str = DEFAULT_META_POSTGRES_CONN_ID,
) -> None:
    hook = get_postgres_hook(meta_conn_id)
    total_affected = int(target_insert_count) + int(target_update_count) + int(target_delete_count)
    update_sql = f"""
        UPDATE {HIST_TABLE_NAME}
           SET extract_row_count = %s,
               stg_load_row_count = %s,
               target_insert_count = %s,
               target_update_count = %s,
               target_delete_count = %s,
               target_total_affected_count = %s,
               file_write_row_count = %s,
               target_file_path = %s,
               status = 'SUCCESS',
               error_message = '',
               end_tm = NOW(),
               update_tm = NOW()
         WHERE run_hist_id = %s
    """
    hook.run(update_sql, parameters=(
        extract_row_count, stg_load_row_count, target_insert_count,
        target_update_count, target_delete_count, total_affected,
        file_write_row_count, target_file_path or "", run_hist_id,
    ))


# ****** standalone + airflow 전용 ******
def update_etl_run_hist_failed(
    run_hist_id: int,
    error_message: str,
    extract_row_count: int = 0,
    stg_load_row_count: int = 0,
    target_insert_count: int = 0,
    target_update_count: int = 0,
    target_delete_count: int = 0,
    file_write_row_count: int = 0,
    target_file_path: str | None = None,
    meta_conn_id: str = DEFAULT_META_POSTGRES_CONN_ID,
) -> None:
    hook = get_postgres_hook(meta_conn_id)
    total_affected = int(target_insert_count) + int(target_update_count) + int(target_delete_count)
    update_sql = f"""
        UPDATE {HIST_TABLE_NAME}
           SET extract_row_count = %s,
               stg_load_row_count = %s,
               target_insert_count = %s,
               target_update_count = %s,
               target_delete_count = %s,
               target_total_affected_count = %s,
               file_write_row_count = %s,
               target_file_path = %s,
               status = 'FAILED',
               error_message = %s,
               end_tm = NOW(),
               update_tm = NOW()
         WHERE run_hist_id = %s
    """
    hook.run(update_sql, parameters=(
        extract_row_count, stg_load_row_count, target_insert_count,
        target_update_count, target_delete_count, total_affected,
        file_write_row_count, target_file_path or "", cut_text(error_message, 4000),
        run_hist_id,
    ))


# ****** standalone + airflow 전용 ******
def parse_csv_columns(raw_value: str | None) -> list[str]:
    if raw_value is None:
        return []

    return [c.strip() for c in raw_value.split(",") if c and c.strip()]


# ****** standalone + airflow 전용 ******
def parse_column_mapping(raw_mapping: str | None) -> dict[str, str]:
    if raw_mapping is None:
        return {}

    raw_mapping = raw_mapping.strip()

    if not raw_mapping:
        return {}

    try:
        parsed = json.loads(raw_mapping)

        if isinstance(parsed, dict):
            result = {}

            for k, v in parsed.items():
                src = str(k).strip()
                tgt = str(v).strip()

                if not src or not tgt:
                    raise ValueError(
                        f"Invalid column_mapping JSON entry: {k}:{v}"
                    )

                result[src] = tgt

            return result

        if isinstance(parsed, list):
            result = {}

            for item in parsed:
                if not isinstance(item, dict):
                    raise ValueError(
                        f"Invalid column_mapping JSON list item: {item}"
                    )

                if "source" not in item or "target" not in item:
                    raise ValueError(
                        f"Invalid column_mapping JSON list item: {item}"
                    )

                src = str(item["source"]).strip()
                tgt = str(item["target"]).strip()

                if not src or not tgt:
                    raise ValueError(
                        f"Invalid column_mapping JSON list item: {item}"
                    )

                result[src] = tgt

            return result

    except json.JSONDecodeError:
        pass

    result = {}

    for pair in raw_mapping.split(","):
        pair = pair.strip()

        if not pair:
            continue

        if ":" in pair:
            src, tgt = pair.split(":", 1)
        elif "=" in pair:
            src, tgt = pair.split("=", 1)
        else:
            raise ValueError(
                f"Invalid column_mapping format: {raw_mapping}"
            )

        src = src.strip()
        tgt = tgt.strip()

        if not src or not tgt:
            raise ValueError(
                f"Invalid column_mapping pair: {pair}"
            )

        result[src] = tgt

    return result


# ****** standalone + airflow 전용 ******
def parse_input_params(raw_input_param: str | None) -> dict[str, str]:
    if raw_input_param is None:
        return {}

    raw_input_param = raw_input_param.strip()

    if not raw_input_param:
        return {}

    try:
        parsed = json.loads(raw_input_param)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid input_param JSON: {raw_input_param}") from e

    if not isinstance(parsed, dict):
        raise ValueError(
            f"input_param must be JSON object(dict): {raw_input_param}"
        )

    result = {}

    for k, v in parsed.items():
        key = str(k).strip()
        val = "" if v is None else str(v)

        if not key:
            raise ValueError(f"Invalid input_param key: {k}")

        result[key] = val

    return result


# ****** standalone + airflow 전용 ******
def parse_config_option(raw_config_option: str | None) -> dict[str, str]:
    if raw_config_option is None:
        return {}

    raw_config_option = raw_config_option.strip()

    if not raw_config_option:
        return {}

    try:
        parsed = json.loads(raw_config_option)
    except json.JSONDecodeError as e:
        raise ValueError(
            f"Invalid config_option JSON: {raw_config_option}"
        ) from e

    if not isinstance(parsed, dict):
        raise ValueError(
            f"config_option must be JSON object(dict): {raw_config_option}"
        )

    result = {}

    for k, v in parsed.items():
        key = str(k).strip().upper()
        val = "" if v is None else str(v).strip()

        if not key:
            raise ValueError(f"Invalid config_option key: {k}")

        result[key] = val

    return result


# ****** standalone + airflow 전용 ******
def apply_input_params(text: str | None, input_params: dict[str, str]) -> str:
    if text is None:
        return ""

    result = text.strip()

    if not result:
        return ""

    if not input_params:
        return result

    for key in sorted(input_params.keys(), key=len, reverse=True):
        result = result.replace(key, input_params[key])

    return result


# ****** standalone + airflow 전용 ******
def normalize_csv_delimiter(raw_delimiter: str | None) -> str:
    if raw_delimiter is None:
        return ","

    delimiter = str(raw_delimiter).strip()

    if not delimiter:
        return ","

    if delimiter in ("\\t", "tab", "TAB"):
        return "\t"

    return delimiter


# ****** standalone + airflow 전용 ******
def normalize_file_encoding(raw_encoding: str | None) -> str:
    if raw_encoding is None:
        return "utf-8"

    encoding = str(raw_encoding).strip().lower()

    if not encoding:
        return "utf-8"

    if encoding in ("utf8", "utf-8"):
        return "utf-8"

    if encoding in ("euckr", "euc-kr"):
        return "euc-kr"

    if encoding in ("cp949", "ms949"):
        return "cp949"

    raise ValueError(
        f"Unsupported source_file_encoding: {raw_encoding}. "
        f"Allowed values are utf-8, euc-kr, cp949."
    )


# ****** standalone + airflow 전용 ******
def read_file_all_rows(
    file_path: str,
    file_type: str,
    text_source_column: str = "line_text",
    csv_file_delimiter: str = ",",
    encoding: str = "utf-8",
) -> tuple[list[str], list[tuple]]:
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"Source file not found: {file_path}")

    file_type = file_type.lower().strip()

    if file_type == "csv":
        delimiter = normalize_csv_delimiter(csv_file_delimiter)

        with path.open("r", encoding=encoding, newline="") as f:
            reader = csv.DictReader(f, delimiter=delimiter)

            if not reader.fieldnames:
                raise ValueError(f"CSV header not found: {file_path}")

            source_columns = [str(c).strip() for c in reader.fieldnames]
            all_rows = [
                tuple(row.get(col) for col in source_columns)
                for row in reader
            ]

        return source_columns, all_rows

    if file_type == "json":
        with path.open("r", encoding=encoding) as f:
            content = f.read().strip()

        if not content:
            raise ValueError(f"JSON file is empty: {file_path}")

        if content.startswith("["):
            obj = json.loads(content)

            if not isinstance(obj, list):
                raise ValueError(f"JSON file must be array: {file_path}")

            if not obj:
                return [], []

            first_row = obj[0]

            if not isinstance(first_row, dict):
                raise ValueError(
                    f"JSON array row must be object(dict): {file_path}"
                )

            source_columns = [str(k).strip() for k in first_row.keys()]
            all_rows = []

            for row in obj:
                if not isinstance(row, dict):
                    raise ValueError(
                        f"JSON array row must be object(dict): {file_path}"
                    )

                all_rows.append(tuple(row.get(col) for col in source_columns))

            return source_columns, all_rows

        lines = [line.strip() for line in content.splitlines() if line.strip()]

        if not lines:
            return [], []

        first_obj = json.loads(lines[0])

        if not isinstance(first_obj, dict):
            raise ValueError(
                f"NDJSON row must be object(dict): {file_path}"
            )

        source_columns = [str(k).strip() for k in first_obj.keys()]
        all_rows = []

        for line in lines:
            row = json.loads(line)

            if not isinstance(row, dict):
                raise ValueError(
                    f"NDJSON row must be object(dict): {file_path}"
                )

            all_rows.append(tuple(row.get(col) for col in source_columns))

        return source_columns, all_rows

    if file_type == "text":
        source_columns = [text_source_column]

        with path.open("r", encoding=encoding) as f:
            all_rows = [(line.rstrip("\r\n"),) for line in f]

        return source_columns, all_rows

    raise ValueError(
        f"Unsupported source_file_type: {file_type}. "
        f"Allowed values are json, csv, text."
    )


# ****** standalone + airflow 전용 ******
def get_single_table_config(
    dag_id: str,
    task_name: str,
    meta_postgres_conn_id: str = DEFAULT_META_POSTGRES_CONN_ID,
    today_dt: str | None = None,
) -> dict:
    """
    dag_id + task_name 湲곗??쇰줈 etl_meta_file_to_db 硫뷀? 1嫄대쭔 議고쉶?쒕떎.
    dynamic expand??list媛 ?꾨땲??static task??dict 1嫄댁쓣 諛섑솚?쒕떎.
    """
    meta_hook = get_postgres_hook(meta_postgres_conn_id)

    insert_etl_param_sql = """
    INSERT INTO ETL_PARAM
    WITH BASE_PARAM AS
    (
    SELECT
    YESTERDAY_DT AS P_BASE_DT
    , yyyy || mm || '01' AS P_START_DT
    , YESTERDAY_DT AS P_END_DT
    , BEF_MAX_DAY AS P_BEF_MAX_DT
    , MAX_DAY AS P_MAX_DT
    , yyyy || mm as P_BASE_YM
    FROM ETL_CALENDAR
    WHERE 1=1
    AND TODAY_DT = %s
    )
    SELECT
    DAG_ID
    , TASK_NAME
    , '{"$$P_BASE_DT":"' || P_BASE_DT ||
    '","$$P_START_DT":"' || P_START_DT ||
    '","$$P_END_DT":"' || P_END_DT ||
    '","$$P_START_TM":"' || (INPUT_PARAM::JSON ->> '$$P_END_TM') ||
    '","$$P_END_TM":"' || TO_CHAR(TIMEZONE('ASIA/SEOUL', NOW())::TIMESTAMP, 'YYYYMMDDHH24MISS') ||
    '","$$P_BEF_MAX_DT":"' || P_BEF_MAX_DT ||
    '","$$P_MAX_DT":"' || P_MAX_DT ||
    '","$$P_BASE_YM":"' || P_BASE_YM ||
    '"}' AS TOBE_PARAM
    , A.INPUT_PARAM AS ASIS_PARAM
    , TIMEZONE('ASIA/SEOUL', NOW())::TIMESTAMP AS CREATED_TM
    , 'AIRFLOW' AS CREATE_USER_ID
    FROM etl_meta_file_to_db A, BASE_PARAM B
    WHERE 1=1
    AND DAG_ID = %s
    AND TASK_NAME = %s
    AND DISABLE_DT = '20991231'
    AND ENABLE_YN = 'Y'
    """
    update_input_param_sql = """
    UPDATE etl_meta_file_to_db a
    SET input_param = b.tobe_param
    FROM (
        SELECT dag_id, task_name, tobe_param
        FROM etl_param a
        WHERE dag_id = %s
          AND task_name = %s
          AND (task_name, created_tm) = (
                SELECT b.task_name, b.created_tm
                FROM (
                    SELECT dag_id, task_name, created_tm
                    FROM etl_param
                    WHERE dag_id = a.dag_id
                      AND task_name = a.task_name
                    ORDER BY created_tm DESC
                ) b
                LIMIT 1
          )
    ) b
    WHERE a.dag_id = b.dag_id
      AND a.task_name = b.task_name
    """

    select_meta_sql = """
    SELECT
        task_name,
        COALESCE(exec_seq, 999999) AS exec_seq,
        source_table,
        target_table,
        pk_column,
        column_mapping,
        load_option,
        stg_drop_yn,
        source_file_type,
        csv_file_delimiter,
        source_file_encoding,
        source_file_dir,
        source_pre_cmd,
        target_pre_sql,
        target_post_sql,
        config_option,
        input_param
    FROM etl_meta_file_to_db
    WHERE 1=1
      AND enable_yn = 'Y'
      AND dag_id = %s
      AND task_name = %s
      AND disable_dt = '20991231'
    """

    conn = None
    cursor = None

    try:
        conn = meta_hook.get_conn()
        conn.autocommit = False
        cursor = conn.cursor()

        cursor.execute("SET TIME ZONE 'Asia/Seoul'")


        if today_dt is not None:
            cursor.execute(insert_etl_param_sql, (today_dt, dag_id, task_name))

        cursor.execute(update_input_param_sql, (dag_id, task_name))
        cursor.execute(select_meta_sql, (dag_id, task_name))
        rows = cursor.fetchall()

        conn.commit()

    except Exception:
        if conn is not None:
            conn.rollback()
        raise

    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()

    if not rows:
        raise ValueError(
            f"ETL meta not found. dag_id={dag_id}, task_name={task_name}"
        )

    if len(rows) > 1:
        raise ValueError(
            f"ETL meta must be unique. dag_id={dag_id}, task_name={task_name}, count={len(rows)}"
        )

    r = rows[0]

    meta_task_name = (r[0] or "").strip() if r[0] is not None else ""
    exec_seq = int(r[1]) if r[1] is not None else 999999
    source_table = (r[2] or "").strip() if r[2] is not None else ""
    target_table = (r[3] or "").strip() if r[3] is not None else ""
    pk_columns = parse_csv_columns(r[4])
    column_mapping = r[5]
    load_option = (r[6] or "di").strip().lower() if r[6] is not None else "di"
    stg_drop_yn = (r[7] or "N").strip().upper() if r[7] is not None else "N"
    source_file_type = (r[8] or "").strip().lower() if r[8] is not None else ""
    csv_file_delimiter = (r[9] or ",") if r[9] is not None else ","
    source_file_encoding = (r[10] or "utf-8").strip() if r[10] is not None else "utf-8"
    source_file_dir = (r[11] or "").strip() if r[11] is not None else ""
    source_pre_cmd = (r[12] or "").strip() if r[12] is not None else ""
    target_pre_sql = (r[13] or "").strip() if r[13] is not None else ""
    target_post_sql = (r[14] or "").strip() if r[14] is not None else ""
    config_option = (r[15] or "").strip() if r[15] is not None else ""
    input_param = (r[16] or "").strip() if r[16] is not None else ""

    if not meta_task_name:
        meta_task_name = task_name

    normalized_source_file_encoding = normalize_file_encoding(source_file_encoding)
    parsed_config_option = parse_config_option(config_option)
    target_conn_name = (parsed_config_option.get("TARGET_CONN_NAME") or "").strip()

    if not source_table:
        raise ValueError("etl_meta_file_to_db.source_table(file_name/pattern) is empty")

    if not target_table:
        raise ValueError("etl_meta_file_to_db.target_table is empty")

    if load_option not in ("ui", "di", "ti", "i", "u", "d"):
        raise ValueError(
            f"{target_table}: invalid load_option [{load_option}]. "
            f"Allowed values are ui, di, ti, i, u, d."
        )

    if stg_drop_yn not in ("Y", "N"):
        raise ValueError(
            f"{target_table}: invalid stg_drop_yn [{stg_drop_yn}]. "
            f"Allowed values are Y, N."
        )

    if source_file_type not in ("json", "csv", "text"):
        raise ValueError(
            f"{target_table}: invalid source_file_type [{source_file_type}]. "
            f"Allowed values are json, csv, text."
        )

    if source_file_type == "csv" and not csv_file_delimiter:
        raise ValueError(f"{target_table}: csv_file_delimiter is empty for csv source")

    if not source_file_dir:
        raise ValueError(f"{target_table}: source_file_dir is empty")

    if load_option in ("ui", "di", "u", "d") and not pk_columns:
        raise ValueError(
            f"{target_table}: pk_column is required for load_option [{load_option}]"
        )

    if not target_conn_name:
        raise ValueError(f"{target_table}: config_option.TARGET_CONN_NAME is empty")

    return {
        "task_name": meta_task_name,
        "exec_seq": exec_seq,
        "source_table": source_table,
        "target_table": target_table,
        "pk_columns": pk_columns,
        "column_mapping": column_mapping,
        "load_option": load_option,
        "stg_drop_yn": stg_drop_yn,
        "source_file_type": source_file_type,
        "csv_file_delimiter": csv_file_delimiter,
        "source_file_encoding": normalized_source_file_encoding,
        "source_file_dir": source_file_dir,
        "source_pre_cmd": source_pre_cmd,
        "target_pre_sql": target_pre_sql,
        "target_post_sql": target_post_sql,
        "config_option": parsed_config_option,
        "input_param": input_param,
        "target_conn_name": target_conn_name,
    }


# ****** standalone + airflow 전용 ******
def run_file_to_postgres_etl(
    dag_id: str,
    task_name: str,
    meta_postgres_conn_id: str = DEFAULT_META_POSTGRES_CONN_ID,
    today_dt: str | None = None,
    **context,
):
    """
    static task?먯꽌 吏곸젒 ?몄텧?섎뒗 File -> PostgreSQL ETL 怨듯넻 ?⑥닔.
    dag_id + task_name 湲곗??쇰줈 硫뷀? 1嫄?議고쉶 ??ETL ?섑뻾.
    """
    runtime_info = get_task_runtime_info(**context)

    table_config = get_single_table_config(
        dag_id=dag_id,
        task_name=task_name,
        meta_postgres_conn_id=meta_postgres_conn_id,
        today_dt=today_dt,
    )

    meta_task_name = (table_config.get("task_name") or "").strip()
    exec_seq = table_config.get("exec_seq")

    source_table = (table_config.get("source_table") or "").strip()
    target_table = (table_config.get("target_table") or "").strip()
    pk_columns = table_config.get("pk_columns") or []
    raw_column_mapping = table_config.get("column_mapping")
    load_option = (table_config.get("load_option") or "di").strip().lower()
    stg_drop_yn = (table_config.get("stg_drop_yn") or "N").strip().upper()

    raw_source_file_type = (table_config.get("source_file_type") or "").strip().lower()
    raw_csv_file_delimiter = str(table_config.get("csv_file_delimiter") or ",")
    raw_source_file_encoding = str(table_config.get("source_file_encoding") or "utf-8")
    raw_source_file_dir = (table_config.get("source_file_dir") or "").strip()
    raw_source_pre_cmd = (table_config.get("source_pre_cmd") or "").strip()
    raw_target_pre_sql = (table_config.get("target_pre_sql") or "").strip()
    raw_target_post_sql = (table_config.get("target_post_sql") or "").strip()
    raw_input_param = table_config.get("input_param")

    config_option = table_config.get("config_option") or {}
    target_conn_name = (table_config.get("target_conn_name") or "").strip()

    print(
        f"START ETL "
        f"dag_id={dag_id}, "
        f"task_name={meta_task_name}, "
        f"exec_seq={exec_seq}, "
        f"source_table={source_table}, "
        f"target_table={target_table}"
    )

    run_hist_id = None
    extract_row_count = 0
    stg_load_row_count = 0
    target_insert_count = 0
    target_update_count = 0
    target_delete_count = 0
    file_write_row_count = 0
    target_file_path = ""

    try:
        if not target_conn_name:
            raise ValueError(f"{target_table}: config_option.TARGET_CONN_NAME is empty")

        run_hist_id = insert_etl_run_hist(
            dag_id=dag_id,
            run_id=runtime_info["run_id"],
            task_id=meta_task_name or runtime_info["task_id"],
            map_index=runtime_info["map_index"],
            source_table=source_table,
            target_table=target_table,
            load_option=load_option,
            source_conn_name="",
            target_conn_name=target_conn_name,
            input_param=raw_input_param,
            config_option={
                **config_option,
                "AIRFLOW_TASK_ID": runtime_info["task_id"],
                "TASK_NAME": meta_task_name,
                "EXEC_SEQ": str(exec_seq),
            },
            meta_conn_id=meta_postgres_conn_id,
        )

        input_params = parse_input_params(raw_input_param)

        source_file_type = apply_input_params(raw_source_file_type, input_params).lower()
        csv_file_delimiter = apply_input_params(raw_csv_file_delimiter, input_params)
        normalized_csv_file_delimiter = normalize_csv_delimiter(csv_file_delimiter)

        source_file_encoding = apply_input_params(raw_source_file_encoding, input_params)
        normalized_source_file_encoding = normalize_file_encoding(source_file_encoding)

        source_file_dir = apply_input_params(raw_source_file_dir, input_params)
        source_pre_cmd = apply_input_params(raw_source_pre_cmd, input_params)
        target_pre_sql = apply_input_params(raw_target_pre_sql, input_params)
        target_post_sql = apply_input_params(raw_target_post_sql, input_params)
        source_file_pattern = apply_input_params(source_table, input_params)

        if source_file_type == "csv" and not normalized_csv_file_delimiter:
            raise ValueError(
                f"{target_table}: csv_file_delimiter is empty after param replacement"
            )

        source_dir_path = Path(source_file_dir)
        matched_files = sorted(source_dir_path.glob(source_file_pattern))

        print(f"[DEBUG] dag_id={dag_id}")
        print(f"[DEBUG] task_name={meta_task_name}")
        print(f"[DEBUG] exec_seq={exec_seq}")
        print(f"[DEBUG] target_conn_name={target_conn_name}")
        print(f"[DEBUG] source_file_dir={source_file_dir}")
        print(f"[DEBUG] source_file_pattern={source_file_pattern}")
        print(f"[DEBUG] matched_files={[str(p) for p in matched_files]}")
        print(f"[DEBUG] matched_file_count={len(matched_files)}")
        print(f"[DEBUG] source_file_type={source_file_type}")
        print(f"[DEBUG] csv_file_delimiter_raw={csv_file_delimiter}")
        print(f"[DEBUG] csv_file_delimiter_normalized={repr(normalized_csv_file_delimiter)}")
        print(f"[DEBUG] source_file_encoding_raw={source_file_encoding}")
        print(f"[DEBUG] source_file_encoding_normalized={normalized_source_file_encoding}")

        if not matched_files:
            raise FileNotFoundError(
                f"{target_table}: no source files matched. "
                f"source_file_dir=[{source_file_dir}], source_table(pattern)=[{source_file_pattern}]"
            )

        stg_table = f"stg_{target_table}"

        create_stg_sql = f"""
            CREATE TABLE IF NOT EXISTS {stg_table}
            (LIKE {target_table} INCLUDING ALL)
        """

        truncate_stg_sql = f"TRUNCATE TABLE {stg_table}"
        truncate_target_sql = f"TRUNCATE TABLE {target_table}"
        drop_stg_sql = f"DROP TABLE IF EXISTS {stg_table}"

        target_hook = get_postgres_hook(target_conn_name)

        target_tx_conn = None
        target_tx_cursor = None
        job_succeeded = False

        try:
            if source_pre_cmd:
                completed = subprocess.run(
                    source_pre_cmd,
                    shell=True,
                    check=True,
                    capture_output=True,
                    text=True,
                )
                if completed.stdout:
                    print(completed.stdout)
                if completed.stderr:
                    print(completed.stderr)

            target_hook.run(create_stg_sql)
            target_hook.run(truncate_stg_sql)

            column_mapping = parse_column_mapping(raw_column_mapping) or {}

            if source_file_type == "text":
                if column_mapping:
                    if len(column_mapping) != 1:
                        raise ValueError(
                            f"{target_table}: text file requires exactly one column mapping"
                        )
                    text_source_column = list(column_mapping.keys())[0]
                else:
                    text_source_column = "line_text"
            else:
                text_source_column = "line_text"

            expected_source_columns = None
            target_columns = None

            for file_path in matched_files:
                source_columns, all_rows = read_file_all_rows(
                    file_path=str(file_path),
                    file_type=source_file_type,
                    text_source_column=text_source_column,
                    csv_file_delimiter=normalized_csv_file_delimiter,
                    encoding=normalized_source_file_encoding,
                )

                print(f"[DEBUG] current_file={str(file_path)}")
                print(f"[DEBUG] source_columns={source_columns}")
                print(f"[DEBUG] total_read_rows={len(all_rows)}")
                print(f"[DEBUG] sample_rows={all_rows[:5]}")

                if not source_columns and not all_rows:
                    print(f"{target_table}: source file has no rows [{file_path}]")
                    continue

                if source_file_type in ("csv", "json") and not source_columns:
                    raise ValueError(
                        f"{target_table}: no source columns detected from file [{file_path}]"
                    )

                if expected_source_columns is None:
                    expected_source_columns = source_columns
                    target_columns = [
                        column_mapping.get(src_col, src_col)
                        for src_col in expected_source_columns
                    ]

                    if not target_columns and all_rows:
                        raise ValueError(f"{target_table}: mapped target_columns is empty")

                    if len(set(target_columns)) != len(target_columns):
                        raise ValueError(
                            f"{target_table}: duplicate target columns detected after mapping. "
                            f"source_columns={expected_source_columns}, target_columns={target_columns}"
                        )

                    pk_columns_upper = [str(pk).strip().upper() for pk in pk_columns]
                    target_columns_upper = [str(col).strip().upper() for col in target_columns]

                    missing_pk_columns = [
                        #pk for pk in pk_columns if pk not in target_columns
                        pk for pk in pk_columns_upper
                        if str(pk).strip().upper() not in target_columns_upper
                    ]

                    if missing_pk_columns:
                        raise ValueError(
                            f"{target_table}: mapped result does not include PK columns: "
                            f"{missing_pk_columns}. "
                            f"source_columns={expected_source_columns}, "
                            f"target_columns={target_columns}"
                        )

                else:
                    if source_columns != expected_source_columns:
                        raise ValueError(
                            f"{target_table}: source columns mismatch across files. "
                            f"expected={expected_source_columns}, "
                            f"current={source_columns}, file={file_path}"
                        )

                if all_rows:
                    target_hook.insert_rows(
                        table=stg_table,
                        rows=all_rows,
                        target_fields=target_columns,
                        commit_every=max(1, len(all_rows)),
                        executemany=True,
                    )

                    stg_count = target_hook.get_first(f"SELECT COUNT(*) FROM {stg_table}")[0]

                    extract_row_count += len(all_rows)
                    stg_load_row_count += len(all_rows)

                    print(
                        f"{file_path} -> {stg_table} "
                        f"file_rows={len(all_rows)} "
                        f"total_rows={stg_load_row_count} "
                        f"stg_count_after_insert={stg_count} "
                        f"source_columns={source_columns} "
                        f"target_columns={target_columns}"
                    )

            if stg_load_row_count > 0:
                insert_columns_sql = ", ".join(target_columns)
                select_columns_sql = ", ".join([f"s.{col}" for col in target_columns])

                insert_sql = f"""
                    INSERT INTO {target_table} ({insert_columns_sql})
                    SELECT {select_columns_sql}
                    FROM {stg_table} s
                """

                pk_join_condition_sql = " AND ".join(
                    [f"t.{pk} = s.{pk}" for pk in pk_columns]
                )

                non_pk_columns = [c for c in target_columns if c not in pk_columns]

                if non_pk_columns:
                    update_set_sql = ", ".join(
                        [f"{col} = s.{col}" for col in non_pk_columns]
                    )
                    update_sql = f"""
                        UPDATE {target_table} t
                        SET {update_set_sql}
                        FROM {stg_table} s
                        WHERE {pk_join_condition_sql}
                    """
                else:
                    update_sql = None

                not_exists_condition_sql = " AND ".join(
                    [f"t.{pk} = s.{pk}" for pk in pk_columns]
                )

                insert_not_exists_sql = f"""
                    INSERT INTO {target_table} ({insert_columns_sql})
                    SELECT {select_columns_sql}
                    FROM {stg_table} s
                    WHERE NOT EXISTS (
                        SELECT 1
                        FROM {target_table} t
                        WHERE {not_exists_condition_sql}
                    )
                """

                delete_sql = f"""
                    DELETE FROM {target_table} t
                    WHERE EXISTS (
                        SELECT 1
                        FROM {stg_table} s
                        WHERE {pk_join_condition_sql}
                    )
                """

                target_tx_conn = target_hook.get_conn()
                target_tx_conn.autocommit = False
                target_tx_cursor = target_tx_conn.cursor()

                try:
                    if target_pre_sql:
                        target_tx_cursor.execute(target_pre_sql)
                        print(f"{target_table} target_pre_sql completed")

                    if load_option == "ui":
                        if update_sql:
                            target_tx_cursor.execute(update_sql)
                            target_update_count = target_tx_cursor.rowcount
                            print(f"{target_table} UPDATE completed")

                        target_tx_cursor.execute(insert_not_exists_sql)
                        target_insert_count = target_tx_cursor.rowcount
                        print(
                            f"{stg_table} -> {target_table} INSERT completed (UI), "
                            f"total={stg_load_row_count}"
                        )

                    elif load_option == "di":
                        target_tx_cursor.execute(delete_sql)
                        target_delete_count = target_tx_cursor.rowcount
                        print(f"{target_table} DELETE completed")

                        target_tx_cursor.execute(insert_sql)
                        target_insert_count = target_tx_cursor.rowcount
                        print(
                            f"{stg_table} -> {target_table} INSERT completed (DI), "
                            f"total={stg_load_row_count}"
                        )

                    elif load_option == "ti":
                        target_tx_cursor.execute(truncate_target_sql)
                        print(f"{target_table} TRUNCATE completed")

                        target_tx_cursor.execute(insert_sql)
                        target_insert_count = target_tx_cursor.rowcount
                        print(
                            f"{stg_table} -> {target_table} INSERT completed (TI), "
                            f"total={stg_load_row_count}"
                        )

                    elif load_option == "i":
                        target_tx_cursor.execute(insert_sql)
                        target_insert_count = target_tx_cursor.rowcount
                        print(
                            f"{stg_table} -> {target_table} INSERT completed (I), "
                            f"total={stg_load_row_count}"
                        )

                    elif load_option == "u":
                        if not update_sql:
                            print(
                                f"{target_table}: no non-pk columns to update, UPDATE skipped (U)"
                            )
                        else:
                            target_tx_cursor.execute(update_sql)
                            target_update_count = target_tx_cursor.rowcount
                            print(f"{target_table} UPDATE completed (U)")

                    elif load_option == "d":
                        target_tx_cursor.execute(delete_sql)
                        target_delete_count = target_tx_cursor.rowcount
                        print(f"{target_table} DELETE completed (D)")

                    if target_post_sql:
                        target_tx_cursor.execute(target_post_sql)
                        print(f"{target_table} target_post_sql completed")

                    target_tx_conn.commit()
                    job_succeeded = True

                except Exception:
                    target_tx_conn.rollback()
                    raise

            else:
                print(f"{target_table}: no rows read from matched files, target load skipped")
                job_succeeded = True

        finally:
            if target_tx_cursor is not None:
                target_tx_cursor.close()

            if target_tx_conn is not None:
                target_tx_conn.close()

            if job_succeeded and stg_drop_yn == "Y":
                target_hook.run(drop_stg_sql)
                print(f"{stg_table} dropped (stg_drop_yn=Y)")
            else:
                print(
                    f"{stg_table} kept "
                    f"(job_succeeded={job_succeeded}, stg_drop_yn={stg_drop_yn})"
                )

        update_etl_run_hist_success(
            run_hist_id=run_hist_id,
            extract_row_count=extract_row_count,
            stg_load_row_count=stg_load_row_count,
            target_insert_count=target_insert_count,
            target_update_count=target_update_count,
            target_delete_count=target_delete_count,
            file_write_row_count=file_write_row_count,
            target_file_path=target_file_path,
            meta_conn_id=meta_postgres_conn_id,
        )

        print(
            f"END ETL SUCCESS "
            f"dag_id={dag_id}, "
            f"task_name={meta_task_name}, "
            f"exec_seq={exec_seq}, "
            f"source_table={source_table}, "
            f"target_table={target_table}"
        )

    except Exception:
        print(
            f"END ETL FAILED "
            f"dag_id={dag_id}, "
            f"task_name={task_name}, "
            f"source_table={source_table}, "
            f"target_table={target_table}"
        )

        if run_hist_id is not None:
            update_etl_run_hist_failed(
                run_hist_id=run_hist_id,
                error_message=traceback.format_exc(),
                extract_row_count=extract_row_count,
                stg_load_row_count=stg_load_row_count,
                target_insert_count=target_insert_count,
                target_update_count=target_update_count,
                target_delete_count=target_delete_count,
                file_write_row_count=file_write_row_count,
                target_file_path=target_file_path,
                meta_conn_id=meta_postgres_conn_id,
            )

        raise


# ****** airflow 전용 ******
def create_file_to_postgres_task(
    dag_id: str,
    task_name: str,
    task_id: str | None = None,
    meta_postgres_conn_id: str = DEFAULT_META_POSTGRES_CONN_ID,
    today_dt: str | None = None,
):
    """
    static Airflow task ?앹꽦 ?⑥닔.

    task_name:
        etl_meta_file_to_db.task_name 媛?

    task_id:
        Airflow UI???쒖떆??task_id.
        ?앸왂?섎㈃ task_name??洹몃?濡??ъ슜?쒕떎.
    """
    if airflow_task is None:
        raise RuntimeError(
            "create_file_to_postgres_task() requires Airflow. "
            "Use this file as a CLI script for standalone Python execution."
        )

    airflow_task_id = task_id or task_name

    @airflow_task(task_id=airflow_task_id)
    def _static_etl_task(**context):
        run_file_to_postgres_etl(
            dag_id=dag_id,
            task_name=task_name,
            meta_postgres_conn_id=meta_postgres_conn_id,
            today_dt=today_dt,
            **context,
        )

    return _static_etl_task()
# ****** standalone 전용 ******
def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run static file to PostgreSQL ETL without Airflow."
    )
    parser.add_argument("--dag-id", required=True, help="etl_meta_file_to_db.dag_id")
    parser.add_argument("--task-name", required=True, help="etl_meta_file_to_db.task_name")
    parser.add_argument("--today-dt", required=True, help="ETL_CALENDAR.TODAY_DT")
    parser.add_argument(
        "--meta-postgres-conn-id",
        default=DEFAULT_META_POSTGRES_CONN_ID,
        help="Metadata DB connection id. Default: postgres_conn",
    )
    parser.add_argument(
        "--run-id",
        default=None,
        help="Optional run id for etl_job_run_dtl_hist.",
    )
    parser.add_argument(
        "--task-id",
        default=None,
        help="Optional task id for etl_job_run_dtl_hist.",
    )
    parser.add_argument(
        "--map-index",
        type=int,
        default=-1,
        help="Optional map index for etl_job_run_dtl_hist.",
    )
    return parser


# ****** standalone 전용 ******
def main(argv: list[str] | None = None) -> int:
    global USE_AIRFLOW_HOOKS
    USE_AIRFLOW_HOOKS = False
    args = build_arg_parser().parse_args(argv)
    run_file_to_postgres_etl(
        dag_id=args.dag_id,
        task_name=args.task_name,
        meta_postgres_conn_id=args.meta_postgres_conn_id,
        today_dt=args.today_dt,
        run_id=args.run_id,
        task_id=args.task_id or args.task_name,
        map_index=args.map_index,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
